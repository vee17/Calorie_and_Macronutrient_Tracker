#pragma once

ref class vio
{public:
	int x =5;
	int niks() {
		return x ;
	}
};

